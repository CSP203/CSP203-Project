package a1klik.csp203.a1klik;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.ExecutionException;


public class after_login extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.after_login);
        String data= getIntent().getStringExtra("MyData");
        String user_name=get_name(data);
        int instructor_id=get_id(data);
        set_header(user_name);
        try {
            BackgroundWorker backgroundWorker = new BackgroundWorker(this);
            String type = "get_course";
            String id = Integer.toString(instructor_id);
            String output = backgroundWorker.execute(type, id).get();
            TextView tv_new = (TextView) findViewById(R.id.waitShowScreen);
            courseData courseExracted=new courseData(output,'#');
            while (courseExracted.hasNext())
            {
                tv_new.setText(tv_new.getText().toString()+"\n"+courseExracted.getNextLine());
            }
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        catch (ExecutionException e)
        {
            e.printStackTrace();
        }

    }
    public int get_id(String input)
    {
        String output="";
        int i=0;
        int n=input.length();
        while (i<n && Character.isDigit(input.charAt(i))==true)
        {
            output=output+input.charAt(i);
            i++;
        }
        return Integer.valueOf(output);
    }
    public String get_name(String input)
    {
        String output="";
        int i=0;
        int n=input.length();
        while (i<n && Character.isDigit(input.charAt(i))==true)
        {
            i++;
        }
        while (i<n)
        {
            output=output+input.charAt(i);
            i++;
        }
        return output;
    }
    public void set_header(String input)
    {
        TextView tv = (TextView) findViewById(R.id.loginUserName);
        tv.setText(input);
        return;
    }
}
