package com.example.aditya.a1klik_v1;


import android.support.v7.app.AppCompatActivity;



import android.os.Bundle;

import android.view.View;

import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import android.widget.Toast;


/**
 * A login screen that offers login via email/password.
 */
public class Login extends AppCompatActivity  {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
    EditText username = (EditText) findViewById(R.id.USERNAME);
    EditText pass = (EditText) findViewById(R.id.PASSWORD);
    /*
    public void send(View v)
    {
        //get message from message box
        String  msg = username.getText().toString();

        //check whether the msg empty or not
        if(msg.length()>0) {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://www.yourdomain.com/serverside-script.php");

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("id", "01"));
                nameValuePairs.add(new BasicNameValuePair("message", msg));
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                httpclient.execute(httppost);
                msgTextField.setText(""); //reset the message text field
                Toast.makeText(getBaseContext(),"Sent",Toast.LENGTH_SHORT).show();
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            //display message if text field is empty
            Toast.makeText(getBaseContext(),"All fields are required",Toast.LENGTH_SHORT).show();
        }
    }
    */
    public void check_login(View input)   {
        System.out.println("Well check this out");
        TextView OUTPUT = (TextView) findViewById(R.id.SHOWSCREEN);

        OUTPUT.setText(username.getText().toString() + " " + pass.getText().toString());
        String already=OUTPUT.getText().toString() + "\n";
        String user_input=username.getText().toString();
        String pass_input=pass.getText().toString();
        if (user_input.equals("mukesh") && pass_input.equals("aditya"))
        {
            OUTPUT.setText(already+"Positive login");
        }
        else
        {
            OUTPUT.setText(already+"Negative login");
        }

    }

}

