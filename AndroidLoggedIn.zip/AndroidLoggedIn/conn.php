<?php 
$db_name = "id5418435_oneclick";
$mysql_username = "id5418435_root";
$mysql_password = "12qwaszx";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password,$db_name);

?>